package org.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.appium.mitmproxy.InterceptedMessage;
import io.appium.mitmproxy.MitmproxyJava;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeoutException;

public class Main {

    public static void main(String[] args) throws IOException, TimeoutException, InterruptedException {
       // String mitmdumpPath = "C:\\Users\\Kanishkaran\\AppData\\Roaming\\Python\\Python313\\Scripts\\mitmdump.exe";
       String mitmdumpPath = "/home/ec2-user/.local/bin/mitmdump";
//        String homeDir = System.getProperty("user.home");
//        String mitmdumpPath = homeDir + File.separator + ".local" + File.separator + "bin" + File.separator + "mitmdump";

        Scanner scanner = new Scanner(System.in);

        ObjectMapper mapper = new ObjectMapper();

        List<String> mitmArgs = Arrays.asList("--set", "ssl_insecure=true");

        MitmproxyJava proxy = new MitmproxyJava(mitmdumpPath, (InterceptedMessage message) -> {
            String url = message.getRequest().getUrl();

            if (url.contains("localhost") && "POST".equals(message.getRequest().getMethod())) {
                System.out.println("\nIntercepted POST Request");
                try {
                    JsonNode data = mapper.readTree(message.getRequest().getBody());
                    System.out.println("Original request body: \n" + mapper.writerWithDefaultPrettyPrinter().writeValueAsString(data));

                    while (true) {
                        System.out.print("Enter key to modify/add (type exit to quit): ");
                        String key = scanner.nextLine();
                        if (key.equals("exit")) {
                            System.out.println("Connection closed");
                            break;
                        }
                        System.out.print("Enter value: ");
                        String value = scanner.nextLine();

                        ((ObjectNode) data).put(key, value);
//                    ((ObjectNode) data).put("status", "fail");

                        //message.getRequest().setBody(mapper.writeValueAsBytes(data));
                        message.getResponse().setBody(mapper.writeValueAsBytes(data));
                        System.out.println("Modified request sent: \n" + mapper.writerWithDefaultPrettyPrinter().writeValueAsString(data));
                    }


                } catch (IOException e) {
                    System.err.println("Error processing POST request: " + e.getMessage());
                }
            }
            else if (url.contains("localhost") && "GET".equals(message.getRequest().getMethod())) {
                System.out.println("\nIntercepted GET Response");
                try {
                    JsonNode data = mapper.readTree(message.getResponse().getBody());
                    System.out.println("Original response body: " + mapper.writerWithDefaultPrettyPrinter().writeValueAsString(data));

                    while (true) {
                        System.out.print("Enter key to modify/add (type exit to quit): ");
                        String key = scanner.nextLine();
                        if (key.equals("exit")) {
                            System.out.println("Connection closed");
                            break;
                        }
                        System.out.print("Enter value: ");
                        String value = scanner.nextLine();


                        ((ObjectNode) data).put(key, value);
                        //((ObjectNode) data).put("department", "Movies");

                        message.getResponse().setBody(mapper.writeValueAsBytes(data));
                        System.out.println("Modified response sent: \n" + mapper.writerWithDefaultPrettyPrinter().writeValueAsString(data));
                    }


                } catch (IOException e) {
                    System.err.println("Error processing GET response: " + e.getMessage());
                }
            }
            return message;
        }, 8080, mitmArgs);

        proxy.start();
        System.out.println("Proxy started.");
//        new Scanner(System.in).nextLine();
//        proxy.stop();
//        System.out.println("Proxy stopped.");
    }
}